**1:** only 4 file edits. no changes or replaces. very simple, update proof.

**2:** The Brushes are now dynamically loaded according to bbcodes usage instead of all being loaded even when not in use.

**3:** all themes are included in the js/syntaxhighlighter3/styles/ folder. to change the theme you need to edit the overall_header and change the css themes.

**4:** The copy to clipboard /print thingies are not missing. They are not part to syntax highlighter 3. You will notice if you double click the code or try to highlight it, it does not include the line numbers. this is how you copy the code in version 3

**5:** 100% xHTML valid

**6:** v1.0.1 added 19 (43 in total) more brushes supporting a range of languages

**7:** v1.0.2 an automatic label/title per code box is created in the form of "alias" code so if you used html as an alias it will look like "html code" as seen in the sreenshot

**8:** v1.0.3 fixed matlab brushes with wrong alias / fixed last brush not being loaded / cleaned up code ahead of modb submission

**9:** 1.0.4 fixed according to mod submission refusal, fingers crossed this version they accept

**10:** this mod is available on phpbb.com as an official mod. it is the same mod as the one available here.

**11:** 1.1.0 added a drop down menu to select from a list of pre defined languages

**12:** 1.1.2 used the github version of the scripts for various update reasons. refined the autoloader script. shuffled some code around pre mod submission

**13:** 1.1.3 fixed a problem with the coffescript,masm2 and powershell brushes not loading.

**14:** 1.1.4 added mod validator's notes/warnings to official 1.1.3 minor edits to install.xml and also included minified (optional) versions of the core scripts (not brushes)

**15:** 1.1.5 updated to xregexp 2.0 using a snippet of js code. began process of manually adding in fixes and pull requests. Move all config options to the shCore.js. added some new brushes.

**16:** 1.1.6 included various fixes and pull requests. All these are listed in the github description once they have been committed to the repo.

**17**  1.1.7 added a simple way to change the theme by entering the desired theme in a field in the acp under General/Board Features/ and sql multi line fix